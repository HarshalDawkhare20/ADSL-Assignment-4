import React from "react";

function Landing() {
    return (
        <div>
            <div className="home">
                <div>
                    <div className='container container-fluid text-center text-primary'>
                        <h3 style={{ marginBottom: '10px', paddingTop: '15px', color: "black" }}>Exam Management System </h3>
                    </div>
                </div>
                <section id="about" class="about">
                    <div class="container">

                        <div class="row">
                            <div class="col-lg-6 order-1 order-lg-2" data-aos="zoom-in" data-aos-delay="150">
                                <img src="/bg.jpeg " class="img-fluid" alt="" />
                            </div>
                            <div class="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content text-dark" data-aos="fade-right">
                                <h3>Online Test Portal </h3>
                                <p class="font-italic">
                                <ul className="checkmark-list">
                                <li>
                                  Conducts online test.
                                </li>
                                <li>
                                   To access or manage the data go to navbar's manage ,
                                   then a dropdown will pop up choose the section you want see or modify. 
                                </li>
                              
                                <li>
                                    you will see the data of that selected section.
                                </li>
                                <li>
                                    If you want to add the data directly hover on section you want to edit in manage and infront of that you will see add and view buttons click on that.
                                </li>
                                <li>You can also directly add the data of any section from the view data page of the same section as at bottom-right their is a add icon which will redirct you to add page of that section. </li>
                            </ul>
                                </p>
                            </div>
                        </div>

                    </div>
                </section>
            </div>
        </div>
    );
}

export default Landing;